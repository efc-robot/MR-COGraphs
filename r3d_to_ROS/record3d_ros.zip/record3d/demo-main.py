import numpy as np
from record3d import Record3DStream
import cv2
from threading import Event
import rospy
import rospy
from sensor_msgs.msg import Image, CameraInfo
from nav_msgs.msg import Odometry
import tf
from cv_bridge import CvBridge
import tf2_ros
import geometry_msgs.msg
import time
from scipy.spatial.transform import Rotation
from geometry_msgs.msg import Vector3
import math
from scipy.spatial.transform import Rotation as R

rospy.init_node('record3d_publisher', anonymous=True)
class DemoApp:
    def __init__(self):
        self.event = Event()
        self.session = None
        self.DEVICE_TYPE__TRUEDEPTH = 0
        self.DEVICE_TYPE__LIDAR = 1
        self.image_publisher = rospy.Publisher('camera/image_raw', Image, queue_size=10)
        self.depth_publisher = rospy.Publisher('camera/depth/image_raw', Image, queue_size=10)
        self.camera_info_publisher = rospy.Publisher('camera_info', CameraInfo, queue_size=10)
        self.odom_publisher = rospy.Publisher('odom', Odometry, queue_size=10)
        self.cv_bridge = CvBridge()
        self.br = tf2_ros.TransformBroadcaster()

    def on_new_frame(self):
        """
        This method is called from non-main thread, therefore cannot be used for presenting UI.
        """
        self.event.set()  # Notify the main thread to stop waiting and process new frame.

    def on_stream_stopped(self):
        print('Stream stopped')

    def connect_to_device(self, dev_idx):
        print('Searching for devices')
        devs = Record3DStream.get_connected_devices()
        print('{} device(s) found'.format(len(devs)))
        for dev in devs:
            print('\tID: {}\n\tUDID: {}\n'.format(dev.product_id, dev.udid))

        if len(devs) <= dev_idx:
            raise RuntimeError('Cannot connect to device #{}, try different index.'
                               .format(dev_idx))

        dev = devs[dev_idx]
        self.session = Record3DStream()
        self.session.on_new_frame = self.on_new_frame
        self.session.on_stream_stopped = self.on_stream_stopped
        self.session.connect(dev)  # Initiate connection and start capturing

    def get_intrinsic_mat_from_coeffs(self, coeffs):
        return np.array([[coeffs.fx,         0, coeffs.tx],
                         [        0, coeffs.fy, coeffs.ty],
                         [        0,         0,         1]])

    def start_processing_stream(self):
        while not rospy.is_shutdown():
            self.event.wait()  # Wait for new frame to arrive

            # Copy the newly arrived RGBD frame
            depth = self.session.get_depth_frame()
            rgb = self.session.get_rgb_frame()
            confidence = self.session.get_confidence_frame()
            intrinsic_mat = self.get_intrinsic_mat_from_coeffs(self.session.get_intrinsic_mat())
            camera_pose = self.session.get_camera_pose()  # Quaternion + world position (accessible via camera_pose.[qx|qy|qz|qw|tx|ty|tz])

            current_time = rospy.Time.now()

            # You can now e.g. create point cloud by projecting the depth map using the intrinsic matrix.

            # Postprocess it
            if self.session.get_device_type() == self.DEVICE_TYPE__TRUEDEPTH:
                depth = cv2.flip(depth, 1)
                rgb = cv2.flip(rgb, 1)

            rgb = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)

            # 将rgb和depth逆时针旋转90度
            rgb = cv2.rotate(rgb, cv2.ROTATE_90_COUNTERCLOCKWISE)
            depth = cv2.rotate(depth, cv2.ROTATE_90_COUNTERCLOCKWISE)

            # Publish the image
            image_msg = self.cv_bridge.cv2_to_imgmsg(rgb, encoding="bgr8")
            image_msg.header.stamp = current_time
            image_msg.header.frame_id = "camera"
            self.image_publisher.publish(image_msg)

            # Publish the depth
            depth_msg = self.cv_bridge.cv2_to_imgmsg(depth, encoding="32FC1")
            depth_msg.header.stamp = current_time
            depth_msg.header.frame_id = "camera"
            self.depth_publisher.publish(depth_msg)

            # Publish the camera info
            h,w = rgb.shape[:2]
            info = CameraInfo()
            info.header.frame_id = "camera"
            info.header.stamp = current_time
            info.height = h
            info.width = w
            info.distortion_model = "plumb_bob"
            intrinsic = self.session.get_intrinsic_mat()
            info.D = []  # 默认值
            fx = intrinsic.fx
            fy = intrinsic.fy
            cx = intrinsic.tx
            cy = intrinsic.ty
            K = [fx, 0, cx, 0, fy, cy, 0, 0, 1]
            # 将x和y对调
            # K[0], K[2] = K[2], K[0]
            # K[4], K[5] = K[5], K[4]
            info.K = K  # 从输入参数获取
            info.R = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]  # 默认值
            # info.P = [K[0], 0.0, K[2], 0.0, 0.0, K[4], K[5], 0.0, 0.0, 0.0, 1.0, 0.0]  # 假设没有镜头畸变
            info.P = [fx, 0.0, cx, 0.0, 0.0, fy, cy, 0.0, 0.0, 0.0, 1.0, 0.0]  # 假设没有镜头畸变
            

            # info.K = K  # 从输入参数获取
            # info.R = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]  # 默认值
            # info.P = [K[0], 0.0, K[2], 0.0, 0.0, K[4], K[5], 0.0, 0.0, 0.0, 1.0, 0.0]  # 假设没有镜头畸变
            
            info.binning_x = 0
            info.binning_y = 0
            info.roi.do_rectify = False

            self.camera_info_publisher.publish(info)

            # publish tf
            t_robot = geometry_msgs.msg.TransformStamped()

            print("camera_pose: ", camera_pose.tx, camera_pose.ty, camera_pose.tz)

            original_quaternion = [camera_pose.qx, camera_pose.qy, camera_pose.qz, camera_pose.qw]
            original_matrix = np.zeros((4, 4))
            original_matrix[3, 3] = 1
            original_matrix[0:3, 0:3] = (Rotation.from_quat(original_quaternion)).as_matrix()
            original_matrix[0:3, 3] = np.array([camera_pose.tx, camera_pose.ty, camera_pose.tz])

            # x轴旋转90度
            theta = np.radians(90)
            matrix_x = np.zeros((4, 4))
            matrix_x[3, 3] = 1
            matrix_x[0:3, 0:3] = np.array([
                                    [1, 0, 0],
                                    [0, np.cos(theta), -np.sin(theta)],
                                    [0, np.sin(theta), np.cos(theta)]
                                ])
            matrix_x[0:3, 3] = np.array([0, 0, 0])

            rotation_matrix = np.dot(matrix_x, original_matrix)
            new_quaternion = (Rotation.from_matrix(rotation_matrix[0:3, 0:3])).as_quat()

            t_robot.header.stamp = current_time
            t_robot.header.frame_id = "world"
            t_robot.child_frame_id = "robot"
            t_robot.transform.translation = Vector3(rotation_matrix[0, 3], rotation_matrix[1, 3], rotation_matrix[2, 3]) 
            t_robot.transform.rotation.x = new_quaternion[0]
            t_robot.transform.rotation.y = new_quaternion[1]
            t_robot.transform.rotation.z = new_quaternion[2]
            t_robot.transform.rotation.w = new_quaternion[3]

            # 1.3 before fix 
            # t_camera = geometry_msgs.msg.TransformStamped()
            # t_camera.header.stamp = current_time
            # t_camera.header.frame_id = "robot"
            # t_camera.child_frame_id = "camera"
            # # 设置旋转为绕x轴旋转180度
            # roll = math.pi
            # pitch =  0
            # yaw = 0
            # # 获取四元数
            # quat = R.from_euler('xyz', [roll, pitch, yaw]).as_quat()
            # t_camera.transform.rotation.x = quat[0]
            # t_camera.transform.rotation.y = quat[1]
            # t_camera.transform.rotation.z = quat[2]
            # t_camera.transform.rotation.w = quat[3]

            # t_camera.transform.translation = Vector3(0, 0, 0)

            # trans_list = [t_robot, t_camera]


            t_camera = geometry_msgs.msg.TransformStamped()
            t_camera.header.stamp = current_time
            t_camera.header.frame_id = "robot"
            t_camera.child_frame_id = "camera0"
            # 设置旋转为绕x轴旋转180度
            roll = math.pi
            pitch =  0
            yaw = 0
            # 获取四元数
            quat = R.from_euler('xyz', [roll, pitch, yaw]).as_quat()
            t_camera.transform.rotation.x = quat[0]
            t_camera.transform.rotation.y = quat[1]
            t_camera.transform.rotation.z = quat[2]
            t_camera.transform.rotation.w = quat[3]

            t_camera.transform.translation = Vector3(0, 0, 0)

            t_camera1 = geometry_msgs.msg.TransformStamped()
            t_camera1.header.stamp = current_time
            t_camera1.header.frame_id = "camera0"
            t_camera1.child_frame_id = "camera"
            # 设置旋转为绕z轴旋转90度
            roll = 0
            pitch =  0
            yaw = math.pi/2
            # 获取四元数
            quat = R.from_euler('xyz', [roll, pitch, yaw]).as_quat()
            t_camera1.transform.rotation.x = quat[0]
            t_camera1.transform.rotation.y = quat[1]
            t_camera1.transform.rotation.z = quat[2]
            t_camera1.transform.rotation.w = quat[3]

            t_camera1.transform.translation = Vector3(0, 0, 0)

            trans_list = [t_robot, t_camera, t_camera1]

            self.br.sendTransform(trans_list)

            self.event.clear()

if __name__ == '__main__':
    app = DemoApp()
    app.connect_to_device(dev_idx=0)
    app.start_processing_stream()
