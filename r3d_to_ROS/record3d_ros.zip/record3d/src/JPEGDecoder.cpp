#define STB_IMAGE_IMPLEMENTATION
#include "JPEGDecoder.h"