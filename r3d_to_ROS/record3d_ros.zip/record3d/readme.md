1 在主机上运行roscore

2 在r1板子上运行detic：

source liuhao/detic/setup.bash

roslaunch detic_node run.launch

3 启动iphone上的record3d程序，同时将其设置为usb串流模式，帧率设置为10fps，再在r1板子上运行 iphone 传感器节点：

cd ~/record

python3 demo-main.py

4 启动建图程序：

cd ~/hydra_ws

source devel/setup.bash

roslaunch mr_sgmapping isaac_one_robot_cp1.launch

5 在主机上运行rviz，打开配置文件：
